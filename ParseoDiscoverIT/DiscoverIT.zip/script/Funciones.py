import re
import os
import shutil
import traceback
import os
import napalm
import yaml

def main(output_file):
    print(f'===+++DiscoverIT+++===\n\n')
    device = abrir_archivo(output_file)
    marca,modelo, sn, version, part_number = parsing(device)
    print(f'Modelo: {modelo} \nNumero de serie: {sn}\nNumero de parte: {part_number}\nVersion: {version}')
    impresion = f'\nModelo: {modelo[0]}\nNumero de serie: {sn[0]}\nNumero de parte: {part_number[0]}\nVersion: {version[0]}'
    extension = '.txt'
    archivo_nombre = f"{str(modelo[0])}-{str(sn[0])}{extension}"
    nombre_carpeta = archivo_nombre.split('.')
    print(f'\nSe guardaron los datos con el nombre: {archivo_nombre}')
    carpeta = marca + '-' + nombre_carpeta[0]
    crear_carpeta(carpeta)
    print(carpeta)
    insertar('+++PARSEO+++', impresion, archivo_nombre,carpeta)
    insertar_output(output_file,carpeta)
      # Llamar a la función para analizar los datos de los Power Supply
    power_supply_data = parse_power_supply_brocade(device)

   
    # Imprimir los resultados de los Power Supply
    for model, data in power_supply_data.items():
        print(f"\nModelo de Power Supply: {model}")
        print(f"Cantidad total de Power Supply: {data['total']}")
        print(f"Cantidad de Power Supply funcionando: {data['working']}")
        print(f"Números de serie de Power Supply: {', '.join(data['serial_numbers'])}")
        print(f"Números de parte de Power Supply: {', '.join(data['part_numbers'])}")
        print()

    # Ejemplo de uso con la salida proporcionada en forma de texto

    switch_info = parse_switch_units(device)

    print(f'\n ########### PRUEBA DE PARSEO ##############\n')
    #print(device)
    print(switch_info)

    # prueba de los ventiladores brocade
    print('#################################INFO de los FAN######################')
    fan = ventiladores_brocade(device)
    print(fan)

def conexion(archivo):
    try:
        with open(archivo) as config_file:
            config = yaml.safe_load(config_file)

        device_config = config.get('device', {})
        commands_config = config.get('commands', {})

        print(f'Configuración del dispositivo: {device_config}')
        print(f'Comandos del dispositivo: {commands_config}')

        driver = napalm.get_network_driver("ios")
        device = driver(**device_config)

        print("Opening device")
        device.open()
        print("Device connected")
        device.cli(['skip-page-display']) # Importante
        return device_config, commands_config, device
    except Exception as e:
        print(f"Error ocurrido en la conoxion: {str(e)}")

def execute_commands(device, commands_config):
    try:
        results = {}
        print("IMPRIMIR ciclo for")
        # Ejecutar los comandos y guardar los resultados
        for command_name, command_value in commands_config.items():
            command_output = device.cli([command_value])
            cadena = command_output[command_value]
            results[command_name] = cadena

        # Guardar los resultados en un archivo de texto
        with open('output.txt', 'w') as output_file:
            print("###########PRUEBA#########")
            for command_name, result in results.items():
                output_file.write(f"Command: {command_name}\n")
                output_file.write(f"Result:\n{result}\n\n")
                # output_file.write(str(result))

        print("Resultados guardados en output.txt")

    except Exception as e:
        print(f"Error ocurrido en main: {str(e)}")
        traceback.print_exc()

def detectarMarca(cadena, commands_config, device):
    # Detectar la marca del switch en el resultado del 'show version'
    if "cisco" in cadena.lower():
        print('Comandos para Cisco:', commands_config['cisco'])
        return 'cisco'
    elif "brocade" in cadena.lower():
        print('Comandos para Brocade:', commands_config['brocade'])
        return 'brocade'
    else:
        print("Marca desconocida")
        return None

def insertar(parse, match, archivo, carpeta):
    try:
        # Solo guarda en el archivo la cadena ingresada
        ruta = 'equipos/' + carpeta + '/' + archivo
        print(ruta)
        with open(ruta, 'w') as archivo:
            concat = parse + ':\n' + match
            archivo.write(str(concat))
            archivo.write('\n')
    except Exception as e:
        print(f"Ocurrió un error al intentar escribir en el archivo: {e}")


def insertar_output(output_file,carpeta):
    ruta = 'equipos/'+carpeta+'/'+output_file
    try:  
        shutil.copy(output_file,ruta)
    except Exception as e:
        print(f"Error ocurrido en main: {str(e)}")
        traceback.print_exc()
       

def abrir_archivo(archivo):
    with open(archivo, 'r') as archivo:
        contenido = archivo.read()
    return contenido

def parsing(output):
    pattern = r"HW:\s[S|s]tackable\s(\S+)"

    # Buscar modelo Brocade, sn, part_number
    match = re.search(pattern, output)
    if match:
        modelo = re.findall(pattern, output)
        pn = match.group(1)
        part_number = [pn]
        print("Número de parte del modelo:", part_number)
        sn = re.findall('Serial\s+#:\s+(\S+)', output)
        version = re.findall('Version\s([A-Za-z0-9\.\(+\)]+)', output)
        marca = 'Brocade'
    else:  # Buscar modelo Cisco
        marca = 'Cisco'
        modelo = re.findall('Model [N|n]umber\s+:\s+([A-Z|0-9|-]+)', output)
        sn = re.findall('[S|s]ystem [S|s]erial [N|n]umber\s+:\s+([A-Z|0-9|-]+)', output)
        version = re.findall('Version\s([A-Za-z0-9\.\(+\)]+)', output)
        if "Part Number" in output:
            part_number = re.findall('Part Number\s+:\s+([0-9-]+)', output)
        else:
            part_number = modelo
        print(f'Parseando ...')
    return marca,modelo, sn, version, part_number


def parse_power_supply_brocade(output):
    power_supply_data = {}
    
    # Buscar información de los Power Supply
    pattern = r"Power supply (\d) \(AC - [A-Za-z]+\)\s+present, status (\w+)\n\s+Model Number:\s+(\S+)\n\s+Serial Number:\s+(\S+)"
    matches = re.findall(pattern, output)
    
    for match in matches:
        ps_number = int(match[0])
        status = match[1]
        model_number = match[2]
        serial_number = match[3]
        
        if model_number not in power_supply_data:
            power_supply_data[model_number] = {
                'total': 1,
                'working': 0,
                'serial_numbers': [],
                'part_numbers': []
            }
        else:
            power_supply_data[model_number]['total'] += 1
        
        power_supply_data[model_number]['serial_numbers'].append(serial_number)
        power_supply_data[model_number]['part_numbers'].append(model_number)
        
        if status == 'ok':
            power_supply_data[model_number]['working'] += 1
    
    return power_supply_data


def parse_switch_units(output):
    units = []
    unit_pattern = re.compile(r"Switch\s+(\d+)\s+(.+)\n.+Serial\s*#: (\S+)", re.DOTALL)
    unit_matches = unit_pattern.findall(output)
    Management_Module = 'Management Module'
    count_mm = 1  # Start counting from 1
    count = 0
    for unit in unit_matches:
        if Management_Module in unit[1]:
            nueva = unit[2]  # Extract the serial number
            nueva = tuple([nueva])
            units.append(unit + nueva)
            count += 1
        else:
            units.append(unit)
        count_mm += 1
    
    units = sorted(units, key=lambda tupla: int(tupla[0])) # Sort by unit number

    return units


#ventilador brocade [F|f]an\s+((\d+)\s+[A-Z | a-z]+)+

def ventiladores_brocade(output):
        try:
            fan_ok = 0
            fan_not = 0
            pattern = r'[Ff]an\s+\d+\s+[A-Za-z]+'
            matches = re.findall(pattern, output, re.IGNORECASE)
            
            for match in matches:
                estatus = match.split()[-1].lower()
                if estatus == 'ok':
                    fan_ok += 1
                elif estatus == 'not':
                    fan_not += 1

            ventiladores = fan_ok + fan_not

            print(f"\nLa cantidad de ventiladores es: {ventiladores}, estatus ok: {fan_ok}, estatus not present: {fan_not}")
            return ventiladores
        except Exception as e:
            print(f"Ah Ocurrido un error: {e}")
            return 0


#ventilador cisco [S|s]witch\s[\d]\sFAN\s\d+\sis\s[A-Z]+

def ventiladores_cisco(output):
    try:
        fan_ok = 0
        fan_not = 0
        pattern = '[S|s]witch\s[\d]\sFAN\s\d+\sis\s[A-Z | a-z]+'
        matches = re.findall(pattern,output)
        for match in matches:
            estatus = match[18] + match[19]
            if estatus == 'OK':
                fan_ok = fan_ok + 1
            else:
                if estatus == 'not':
                    fan_not = fan_not + 1
        ventiladores = fan_ok + fan_not

        print(f"\nLa cantidad de ventiladores es: {ventiladores} , estatus ok {fan_ok} , estatus not presen {fan_not}")

        return ventiladores

    except Exception as e:
            print(f"Ah Ocurrido un error: {e}")
            return 0


def crear_carpeta(nombre):
# Se define el nombre de la carpeta o directorio a crear
    directorio = "../discoverit/equipos/" + nombre #checar ruta
    print(f'no esta creando directorios: {directorio}')
    try:
        os.mkdir(directorio)
    except OSError:
        print("La creación del directorio %s falló" % directorio)
    else:
        print("Se ha creado el directorio: %s " % directorio)


if __name__ == '__main__':
    main('output.txt')

